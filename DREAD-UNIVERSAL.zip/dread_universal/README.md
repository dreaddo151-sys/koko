# PROJECT DREAD UNIVERSAL — Foundation Release 0.1.0

This is an early, source-based Ubuntu foundation release of PROJECT DREAD UNIVERSAL.
It includes the current Rust workspace, a local service-discovery API, launch scripts,
and the historical local service endpoint configuration.

**This is not yet the complete universal autonomous platform.** The persistent registry,
orchestration engine, UI, agent/plugin adapters, repair workflow, and installer packages
remain future milestones.

## Current functionality

- Rust/Axum API binds to `127.0.0.1:8765`.
- `GET /health` reports application/version status.
- `GET /api/services` checks configured local endpoints concurrently.
- Discovery is reachability-only; HTTP response does not prove application-level health.
- The app does not start, stop, or modify DREAD Hub, ComfyUI, Ollama, Hermes,
  OpenHands, OpenCode, or GPU services.

## Requirements

- Ubuntu/Linux x86-64 (source build)
- Rust toolchain with Cargo (edition 2024 compatible)
- Network access on first build to download Cargo dependencies

Install Rust if needed: https://rustup.rs/

## Build

From this directory:

    ./scripts/build.sh

## Run in the foreground

    ./dread-universal

Then open:

- http://127.0.0.1:8765/health
- http://127.0.0.1:8765/api/services

## Run in the background

    ./scripts/run-background.sh

Logs and PID are written under `var/`. Stop only this DREAD Universal API with:

    ./scripts/stop-background.sh

## Configuration

Edit `config/services.toml` to add or remove local endpoint checks. For safety, the
current discovery loader accepts loopback HTTP endpoints only (`127.0.0.1`).

## Existing workstation services

This release is separate from your existing DREAD Hub and ComfyUI. It does not replace
them and does not alter the existing GPU Supervisor. Keep the GPU Supervisor as the
sole GPU coordination authority.

## Next planned milestones

1. Persistent component registry and registration/update APIs.
2. Service identity, capability metadata, timestamps and verification states.
3. Orchestration and task lifecycle.
4. Hermes/OpenHands/OpenCode adapters.
5. Pstack and Cursor capability ingestion with compatibility/safety classification.
6. Model/GPU resource integration through the existing DREAD GPU Supervisor.
7. React/TypeScript user interface.
8. Controlled diagnostics, repair, approval, verification and rollback.
9. `.deb` and portable runtime packaging, with acceptance tests.

## Security note

The API binds to loopback only. Do not expose it to a network without adding authentication,
authorization, request limits, and a reviewed security model.
