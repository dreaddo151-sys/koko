use futures::future::join_all;
use reqwest::Client;
use serde::{Deserialize, Serialize};
use std::{fs, time::Duration, time::Instant};

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Service {
    pub id: String,
    pub name: String,
    pub url: String,
    pub role: String,
}

#[derive(Debug, Deserialize)]
pub struct ServiceConfig {
    pub services: Vec<Service>,
}

#[derive(Debug, Serialize)]
pub struct ServiceResult {
    pub id: String,
    pub name: String,
    pub url: String,
    pub role: String,
    pub status: String,
    pub http_status: Option<u16>,
    pub latency_ms: Option<u128>,
    pub detail: String,
}

pub fn load_services(path: &str) -> Result<Vec<Service>, String> {
    let contents = fs::read_to_string(path).map_err(|e| format!("Cannot read {path}: {e}"))?;

    let config: ServiceConfig =
        toml::from_str(&contents).map_err(|e| format!("Invalid service configuration: {e}"))?;

    for service in &config.services {
        if service.id.trim().is_empty()
            || service.name.trim().is_empty()
            || !service.url.starts_with("http://127.0.0.1:")
        {
            return Err(format!("Invalid local service definition: {}", service.id));
        }
    }

    Ok(config.services)
}

async fn check_one(client: Client, service: Service) -> ServiceResult {
    let started = Instant::now();

    match client.get(&service.url).send().await {
        Ok(response) => ServiceResult {
            id: service.id,
            name: service.name,
            url: service.url,
            role: service.role,
            status: "ONLINE".into(),
            http_status: Some(response.status().as_u16()),
            latency_ms: Some(started.elapsed().as_millis()),
            detail: "Endpoint responded; application-level health is not implied".into(),
        },
        Err(error) => ServiceResult {
            id: service.id,
            name: service.name,
            url: service.url,
            role: service.role,
            status: if error.is_timeout() {
                "UNKNOWN".into()
            } else {
                "OFFLINE".into()
            },
            http_status: None,
            latency_ms: Some(started.elapsed().as_millis()),
            detail: if error.is_timeout() {
                "Connection timed out".into()
            } else {
                "Endpoint could not be reached".into()
            },
        },
    }
}

pub async fn discover(services: Vec<Service>) -> Vec<ServiceResult> {
    let client = Client::builder()
        .timeout(Duration::from_secs(2))
        .build()
        .expect("HTTP client configuration should be valid");

    join_all(
        services
            .into_iter()
            .map(|service| check_one(client.clone(), service)),
    )
    .await
}
