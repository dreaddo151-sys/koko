use axum::{Json, Router, extract::State, http::StatusCode, response::IntoResponse, routing::get};
use dread_discovery::{Service, discover, load_services};
use std::{env, sync::Arc};
use tokio::net::TcpListener;

struct AppState {
    services: Vec<Service>,
}

async fn health() -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "project": "PROJECT DREAD UNIVERSAL",
        "status": "online",
        "version": env!("CARGO_PKG_VERSION")
    }))
}

async fn list_services(State(state): State<Arc<AppState>>) -> impl IntoResponse {
    let results = discover(state.services.clone()).await;
    (
        StatusCode::OK,
        Json(serde_json::json!({
            "count": results.len(),
            "services": results
        })),
    )
}

#[tokio::main]
async fn main() {
    let config_path =
        env::var("DREAD_CONFIG").unwrap_or_else(|_| "config/services.toml".to_string());

    let services = load_services(&config_path).unwrap_or_else(|error| {
        eprintln!("DREAD configuration error: {error}");
        std::process::exit(1);
    });

    let state = Arc::new(AppState { services });

    let app = Router::new()
        .route("/health", get(health))
        .route("/api/services", get(list_services))
        .with_state(state);

    let address = "127.0.0.1:8765";
    let listener = TcpListener::bind(address)
        .await
        .expect("Could not bind DREAD API listener");

    println!("PROJECT DREAD UNIVERSAL API listening on http://{address}");
    println!("Health:   http://{address}/health");
    println!("Services: http://{address}/api/services");

    axum::serve(listener, app)
        .await
        .expect("DREAD API server failed");
}
