pub const PROJECT_NAME: &str = "PROJECT DREAD UNIVERSAL";

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum VerificationStatus {
    Pass,
    Fail,
    Blocked,
    NotVerified,
}

#[derive(Debug, Clone)]
pub struct Component {
    pub name: String,
    pub endpoint: Option<String>,
    pub status: VerificationStatus,
}
