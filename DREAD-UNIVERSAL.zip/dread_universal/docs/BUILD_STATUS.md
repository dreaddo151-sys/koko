# PROJECT DREAD UNIVERSAL — Build Status

Version: 0.1.0
Stage: Rust foundation

Existing DREAD services remain separate and must be preserved.

GPU coordination authority:
- Existing dread_gpu_supervisor.py

Initial integration targets:
- Hermes
- OpenHands
- OpenCode
- Ollama
- llama.cpp gateway
- ComfyUI
- Pstack
- Cursor plugins

No existing service is restarted or modified by this foundation.
