# Build status — 0.1.0 foundation archive

Source imported from the user-provided archive and wrapped with build/run documentation.
Source-level API includes `/health` and `/api/services`.

The uploaded source had previously been built successfully on the user's Ubuntu machine.
This packaging environment does not have Rust/Cargo installed, so a fresh binary build
could not be performed here. Run `./scripts/build.sh` on the Ubuntu workstation.

No claim is made that the full roadmap or a compiled `.deb` installer is complete.
