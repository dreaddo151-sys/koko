#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
command -v cargo >/dev/null 2>&1 || {
  echo "Rust/Cargo is required. Install from https://rustup.rs/ and reopen the terminal." >&2
  exit 1
}
cargo build --release -p dread-api
echo
echo "Build complete: $ROOT/target/release/dread-api"
