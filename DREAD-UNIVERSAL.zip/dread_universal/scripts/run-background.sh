#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p "$ROOT/var"
if [[ -f "$ROOT/var/dread-universal.pid" ]] && kill -0 "$(cat "$ROOT/var/dread-universal.pid")" 2>/dev/null; then
  echo "DREAD Universal already running (PID $(cat "$ROOT/var/dread-universal.pid"))."
  exit 0
fi
nohup "$ROOT/dread-universal" >> "$ROOT/var/dread-universal.log" 2>&1 < /dev/null &
echo $! > "$ROOT/var/dread-universal.pid"
sleep 2
if curl -fsS http://127.0.0.1:8765/health; then
  echo
  echo "DREAD Universal started. Log: $ROOT/var/dread-universal.log"
else
  echo "Server did not become healthy. Check $ROOT/var/dread-universal.log" >&2
  exit 1
fi
