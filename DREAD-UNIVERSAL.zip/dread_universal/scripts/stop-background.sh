#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PIDFILE="$ROOT/var/dread-universal.pid"
if [[ ! -f "$PIDFILE" ]]; then
  echo "No DREAD Universal PID file."
  exit 0
fi
PID="$(cat "$PIDFILE")"
if kill -0 "$PID" 2>/dev/null; then
  kill "$PID"
  echo "Stopped DREAD Universal (PID $PID)."
else
  echo "DREAD Universal process was not running."
fi
rm -f "$PIDFILE"
